<?php
$serverName = 'localhost';
$uid = '';
$pwd = '';
$databaseName = 'php';

$conn = sqlsrv_connect($serverName,$connectionInfo);


if($conn){echo ''; }else{echo 'Connection failure<br />';die(print_r(sqlsrv_errors(),TRUE));}

else{
$conexion->select_db("php");    

?>