<?php
 require_once 'conexiones/constantes.php';
session_start();
if (!empty($_POST)) {//compara si el formulario viene vacio
  
    $query = "select A.Id_Usuario FROM Usuarios A ";
	while ($row=$queryResult->fetch(PDO::FETCH_ASSOC)) {
        $id=$row['id_usuario'];
    }

	if (isset($_REQUEST['agregar']))  {
		$queryResult = $pdo->query("INSERT INTO Registros(
			ID_Usuario,
			Direccion,
			Edad,
			Carrera,		
			
		)
		VALUES
			(
				'$_POST[$id]',
				$_POST[DIRECCION],				
				$_POST[EDAD],
				'$_POST[articulo]',
				'$_POST[CARRERA]',
				)"); 
		echo "<div class='alert alert-info'>";
		echo "    <strong>Informacion!</strong> Informacion Agregada";
		echo "</div> ";          
	   }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>TEST </title>
  <link rel="stylesheet" href="css/miestilo.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

</head>
<body>
  <div class="contenedor-formulario">
  <form action="conexiones/constantes.php" id="formlg" method="post">
    <h2>REGISTROS</h2>
      <p>DIRECCION</p>
      <input type="text" name="DIRECCION" class="field" required>
      <p>EDAD</p>
      <input type="text" name="EDAD" class="field" required>
      <p>
        <p>CARRERA</p>
        <input type="text" name="CARRERA" class="field" required>
        <p>
      <input type="submit" value="AGREGAR" class="btn"  id="agregar">
      </p>                    
    </form>
  </div>

 <script src="js/main.js" type="text/javascript"></script>
 <script src="js/jquery-3.2.1.js" type="text/javascript"></script>
 

</body>
</html> 
