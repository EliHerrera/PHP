<?php
 require_once 'conexiones/constantes.php';
session_start();
$user=null;
$query = null;
$messege=null; //Variable de mensaje inicializa a vacio
if (!empty($_POST)) {//compara si el formulario viene vacio
   
  $query = ""select A.Id_Usuario FROM Usuarios A "";
  while ($row=$queryResult->fetch(PDO::FETCH_ASSOC)) {
    $nombre=$row['nombre'];
}
    $prepared = $pdo->prepare($query);
    $prepared->execute([
        'user' => $_POST['user'] ,
        'pws' => $_POST['password']        
    ]);   
    if ($user==null) {
      $message="Usuario o Password Incorrecto!";
    }else{      
      header('Location: registros.php');
      exit;
    }
} 

?>

<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TEST</title>
    <link rel="shortcut icon" href="http://wwww.ejemplo.org/img/favicon.ico" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">   
    <link rel="stylesheet" href="css/styles.css" />
<head>    
<body>
<div class="login-page">
      <div class="form">        
        <form class="register-form" method="POST">
          <input type="text" placeholder="name"/>
          <input type="password" placeholder="password"/>        
          <button>create</button>         
        </form>
        <form class="login-form" method="POST" action="login.php">
          <input type="text" placeholder="username" required="true" name="user" id="user"/>
          <input type="password" placeholder="password" required="true" name="password" id="password" />
          <button>Ingresar</button>
          <p class="message"><a href="#">| Reestablecer Contraseña |</a></p>
          <p class="message"><?php echo $message; ?></p>
        </form>
      </div>
    </div>
</body>
</html>